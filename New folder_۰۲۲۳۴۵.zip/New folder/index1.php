<?php
session_start();
if(isset($_SESSION['message'])){
    echo "<div class='alert'>".$_SESSION['message']."</div>";
    unset($_SESSION['message']);
}
?>
<html lang="fa">
<head>
    <meta charset="UTF-8" >
    <title>صفحه اصلی</title>
    <link rel="stylesheet" href="styless.css">
    
    
</head>
<body>
    
    <header>
        
        <h1>فروشگاه تابلو</h1>
        <nav>
            <ul>
                <li><a href="#">خانه</a></li>
                <li><a href="#">محصولات</a></li>
                <li><a href="#">درباره ما</a></li>
                <li><a href="register.php">ثبت‌نام</a></li>
                <li><a href="login.php">ورود</a></li>
            </ul>
        </nav>
        <br>
        <a href="add_product.php" style="color: white;" >➕ افزودن محصول جدید</a>
    </header>
    
    <main>
        <section class="products">
            <?php
            $host = 'localhost';
            $username = 'root';
            $password = ''; 
            $dbname= 'shop';
            
            
            $conn = new mysqli($host, $username, $password, $dbname);
            if ($conn->connect_error){
             die("خطا در اتصال: " . $conn->connect_error);
            }
            $result = mysqli_query($conn, "SELECT * FROM products");
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='product'>";
                echo "<img src='uploads/" . htmlspecialchars($row['image']) . "' alt='" . htmlspecialchars($row['name']) . "'>";
                echo "<h2>" . htmlspecialchars($row['name']) . "</h2>";
                echo "<p><strong>قیمت:</strong> " . htmlspecialchars($row['price']) . " تومان</p>";
                echo "<p>" . htmlspecialchars($row['description']) . "</p>";
                echo "<button onclick=\"confirmEdit(" . $row['id'] . ")\">ویرایش</button> ";
                echo "<button onclick=\"confirmDelete(" . $row['id'] . ")\">حذف</button>";
                echo "<br><br><button \">افزودن به سبد خرید</button>";


                echo "</div>";
            }
            ?>
        </section>
    </main>
    <div class="footer">
         <div class="container">
            <div class="row">
               <div class="col-md-5">
                  <div class="footer-description">
                     <ul>
                        <li>تضمین اصالت کالاهای فروخته شده</li>
                        <li>فروش برند های معتبر</li>
                        <li>پاسخگویی 24 ساعته</li>
                        <li>امکان پرداخت آنلاین با کارت بانکی و پرداخت در محل</li>
                        <li>امکان بازگشت تا یک هفته در صورت عدم رضایت مشتری</li>
                        <li>خرید آسان و مطمئن</li>
                        <li>قیمت های مناسب</li>
                     </ul>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="footer-description2">
                     <ul>
                        <li><i class="fa fa-truck"></i>تحویل پستی سریع</li>
                        <li><i class="fa fa-plane"></i>ارسال با پست پیشتاز و سفارشی</li>
                        <li><i class="fa fa-cart-arrow-down"></i>خرید آسان و راحت</li>
                     </ul>
                  </div>
               </div>
               <div class="col-md-3">
                  <div class="news-form">
                     <h5>در خبرنامه عضو شوید</h5>
                     <form action="" >
                        <input type="email" placeholder="ایمیل خود را وارد کنید" >
                        <button type="submit" ><i class="fa fa-envelope-o"></i></button>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
    
    
    <script>
    function confirmDelete(id) {
        if (confirm("آیا مطمئن هستید که می‌خواهید این محصول را حذف کنید؟")) {
            window.location.href = "delete_product.php?id=" + id;
        }
    }

    function confirmEdit(id) {
        if (confirm("آیا مطمئن هستید که می‌خواهید این محصول را ویرایش کنید؟")) {
            window.location.href = "edit_product_form.php?id=" + id;
        }
    }
    </script>
</body>
</html>
