
<?php
$host = 'localhost';
$username = 'root';
$password = ''; 
$dbname= 'shop';


$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error){
 die("خطا در اتصال: " . $conn->connect_error);
}
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT image FROM products WHERE id=$id");
    $row = mysqli_fetch_assoc($result);
    unlink("uploads/" . $row['image']);
    mysqli_query($conn, "DELETE FROM products WHERE id=$id");
    header("Location: index1.php");
}
?>
