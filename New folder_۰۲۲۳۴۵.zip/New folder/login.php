<?php
session_start();

if(isset($_SESSION['message'])){
    echo "<div class='alert'>".$_SESSION['message']."</div>";
    unset($_SESSION['message']);
}
?>
<?php
$host = 'localhost';
$username = 'root';
$password = ''; 
$dbname= 'shop';


$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error){
 die("خطا در اتصال: " . $conn->connect_error);
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['username'] = $username;
        $_SESSION['message']= "ورود موفقیت‌آمیز بود";
        header("location:index1.php");
        exit();
        
    } else {
        $_SESSION['message']= "نام کاربری یا رمز عبور اشتباه است";

      
        header("location:login.php");
        exit();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>ورود</title>

    <link rel="stylesheet" href="styless.css">

</head>
<body>

    <main>

        <section class="form-container">
        <h2>فرم ورود</h2>
            <form method="post">
                <label for="username">:نام کاربری</label>
                <input type="text" name="username" id="username" required><br><br>
               
                <label for="password">:رمز عبور</label>
                <input type="password" name="password" id="password" required><br><br>
               
                <button type="submit" name="login">ورود</button>
            </form>
        </section>
    </main>
</body>
</html>