<?php
$host = 'localhost';
$username = 'root';
$password = ''; 
$dbname= 'shop';
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error){
 die("خطا در اتصال: " . $conn->connect_error);
}
session_start();

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];  

    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
    if (mysqli_query($conn, $sql)) {
        
        $_SESSION['message']="ثبت نام با موفقیت انجام شد";
        header("location:index1.php");
        exit();
    } else {
        $_SESSION['message']= "خطا در ثبت نام". $conn->error;
      
        header("location:register.php");
        exit();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>ثبت‌نام</title>
    <link rel="stylesheet" href="styless.css">
    

</head>
<body>
    
    <main>
        <section class="form-container">
        <h2>فرم ثبت‌نام</h2>

            <form method="post">
                <label for="username">:نام کاربری</label>
                <input type="text" name="username" id="username" required><br><br>
               
                <label for="password">:رمز عبور</label>
                <input type="password" name="password" id="password" required><br><br>
               
                <button type="submit" name="register">ثبت‌ نام</button>
            
            </form>
        </section>
    </main>
</body>
</html>