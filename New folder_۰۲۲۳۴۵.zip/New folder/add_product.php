<?php
session_start();
if(isset($_POST['logout'])){
    session_destroy();
    header("location:index1.php");
    exit;
}

?>
<?php
$host = 'localhost';
$username = 'root';
$password = ''; 
$dbname= 'shop';


$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error){
 die("خطا در اتصال: " . $conn->connect_error);
}

if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $upload_dir = "uploads/";
    $file_name = basename($_FILES['image']['name']);
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($file_type, $allowed_types)) {
        $new_file_name = uniqid() . '.' . $file_type;
        $target_file = $upload_dir . $new_file_name;
        if (move_uploaded_file($file_tmp, $target_file)) {
            $sql = "INSERT INTO products (name, price, description, image)
                    VALUES ('$name', '$price', '$description', '$new_file_name')";
            if (mysqli_query($conn, $sql)) {
                echo "<div style='color:green;'> محصول با موفقیت افزوده شد.</div>";
            } else 
            {
                echo "<div style='color:red;'> خطا در ذخیره اطلاعات.</div>";
            }
        } 
        else
         {
            echo "<div style='color:red;'> خطا در آپلود تصویر.</div>";
        }
    } 
    else 
    {
        echo "<div style='color:red;'> فرمت تصویر نامعتبر است.</div>";
    }
}

?>
<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>افزودن محصول</title>
    <link rel="stylesheet" href="styless.css">
</head>
<body>
<main>
<section class="form-container">
    <h2>افزودن محصول جدید</h2>
    <form method="post" enctype="multipart/form-data">
    <label for="text">:نام محصول</label>
       <input type="text" name="name" required><br>

       <label for="text">:قیمت</label>
       <input type="text" name="price" required><br>

       <label for="descripyion">:توضیحات</label>
        <textarea name="description"></textarea><br>
        
     <label for="text">:تصویر محصول</label>
       <input type="file" name="image" required><br>

        <br><button type="submit" name="add" >افزودن</button>
        
    </form>
    </section>
    </main>
</body>
</html>
