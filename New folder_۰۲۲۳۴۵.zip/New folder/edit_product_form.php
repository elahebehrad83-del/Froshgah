<?php
session_start();
if(isset($_POST['logout'])){
    session_destroy();
    header("location:index1.php");
    exit;
}

?>
<?php
$host = 'localhost';
$username = 'root';
$password = ''; 
$dbname= 'shop';


$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error){
 die("خطا در اتصال: " . $conn->connect_error);
}

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM products WHERE id=$id");
$row = mysqli_fetch_assoc($result);

if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];

    if (!empty($_FILES['image']['name'])) {
        $upload_dir = "uploads/";
        $file_name = basename($_FILES['image']['name']);
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($file_type, $allowed_types)) {
            $new_file_name = uniqid() . '.' . $file_type;
            $target_file = $upload_dir . $new_file_name;

            if (move_uploaded_file($file_tmp, $target_file)) {
                $image_update = ", image='$new_file_name'";
            } else {
                echo "<div style='color:red;'>❌ خطا در آپلود تصویر.</div>";
                $image_update = "";
            }
        } else {
            echo "<div style='color:red;'>❌ فرمت تصویر نامعتبر است.</div>";
            $image_update = "";
        }
    } else {
        $image_update = "";
    }

    $sql = "UPDATE products SET name='$name', price='$price', description='$description' $image_update WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "<div style='color:green;'>✅ محصول با موفقیت ویرایش شد.</div>";
    } else {
        echo "<div style='color:red;'>❌ خطا در ذخیره تغییرات.</div>";
    }
}
?>


<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <title>ویرایش محصول</title>
    <link rel="stylesheet" href="styless.css">

</head>
<body>
<main>
<section class="form-container">
    <h2>ویرایش محصول</h2>
    <form method="post" enctype="multipart/form-data">
    <label for="text">:نام محصول</label>
         <input type="text" name="name" value="<?= $row['name'] ?>" required><br>

         <label for="text">:قیمت</label>
       <input type="text" name="price" value="<?= $row['price'] ?>" required><br>

       <label for="descripyion">:توضیحات</label>
     <textarea name="description"><?= $row['description'] ?></textarea><br>

        تصویر فعلی: <br>
        <img src="uploads/<?= $row['image'] ?>" alt="عکس محصول" width="150"><br>
        <label for="file">:تغییر تصویر</label>
         <input type="file" name="image"><br>
        <br>
        <button type="submit" name="add">ذخیره</button>
<br><br>
        <button type="submit" name="logout" >خروج</button>
    </form>
    </section>
    </main>
</body>
</html>